# 💊 Farvec – Sistema de Farmacia

Sistema integral para la gestión de farmacias desarrollado en **PHP**, **Bootstrap** y **MySQL**.

Permite controlar ventas, compras, stock, lotes, proveedores y alertas de vencimientos, optimizando la trazabilidad y gestión diaria de una farmacia.

---

## 🚀 Características principales
- 🔐 Módulo de login y usuarios.
- 🧾 Registro y control de ventas.
- 🧮 Módulo de compras a proveedores.
- 📦 Control de stock con lotes y fechas de vencimiento.
- 📊 Reportes y estadísticas.
- ⚠️ Alertas de bajo stock y productos vencidos.

---

## 🛠️ Tecnologías
- PHP 8.x  
- MySQL / MariaDB  
- Bootstrap 5  
- HTML, CSS, JavaScript  

---

## 🗂️ Estructura del proyecto
```
src/
├── controllers/
├── models/
├── views/
├── includes/
└── public/
```

---

## ⚙️ Instalación

1. Clonar o descargar este repositorio.  
2. Importar `database/farmacia.sql` en tu servidor MySQL.  
3. Configurar tus credenciales en `src/includes/config.php`.  
4. Iniciar Apache y MySQL (por ejemplo, con XAMPP).  
5. Abrir el sistema en el navegador:  
   ```
   http://localhost/Farvec-Sistema-de-Farmacia/src/public/
   ```

---

## 👥 Autores
Desarrollado por el equipo académico del proyecto **Farvec – Sistema de Farmacia**.

---

## 📄 Licencia
Proyecto académico y de uso libre bajo la licencia MIT.

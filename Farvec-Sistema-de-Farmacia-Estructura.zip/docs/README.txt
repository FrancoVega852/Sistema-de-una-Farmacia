Esta carpeta pertenece a docs del proyecto Farvec - Sistema de Farmacia.
Agrega aquí los archivos correspondientes.
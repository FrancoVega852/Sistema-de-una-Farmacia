📁 Carpeta: src/includes
Colocá aquí los archivos correspondientes a esta sección del sistema Farvec.
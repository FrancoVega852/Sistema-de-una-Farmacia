📁 Carpeta: src/views/productos
Colocá aquí los archivos correspondientes a esta sección del sistema Farvec.
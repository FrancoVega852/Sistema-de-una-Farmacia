<?php
// =======================================
// Relación Proveedores ↔ Productos
// =======================================
// Clave: id del proveedor
// Valor: array con ids de productos que vende
// =======================================

return [
    1 => [1, 2], // Droguería Central → Ibuprofeno y Paracetamol
    2 => [2, 3]  // FarmacoPro → Paracetamol y Shampoo Herbal
];

<?php
session_start();
require_once 'Conexion.php';
require_once 'Producto.php';
require_once 'Lote.php';

if (!isset($_SESSION["usuario_id"])) {
    header("Location: login.php");
    exit();
}
if ($_SESSION["usuario_rol"] !== "Administrador") {
    die("⛔ No tienes permisos para acceder a esta página.");
}

$conn = new Conexion();
$productoObj = new Producto($conn->conexion);
$loteObj     = new Lote($conn->conexion);

$mensaje = "";
$exito = false;

// Traer categorías
$categorias = $conn->conexion->query("SELECT id, nombre FROM Categoria ORDER BY nombre ASC");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre          = $_POST["nombre"];
    $precio          = $_POST["precio"];
    $stock_minimo    = $_POST["stock_minimo"];
    $requiere_receta = isset($_POST["requiere_receta"]) ? 1 : 0;
    $categoria_id    = $_POST["categoria_id"];

    $numero_lote       = $_POST["numero_lote"];
    $fecha_vencimiento = $_POST["fecha_vencimiento"];
    $cantidad_inicial  = $_POST["cantidad_inicial"];

    if ($productoObj->agregarProducto($nombre, $precio, 0, $stock_minimo, $requiere_receta, $categoria_id)) {
        $producto_id = $conn->conexion->insert_id;

        if ($loteObj->crear($producto_id, $numero_lote, $fecha_vencimiento, $cantidad_inicial)) {
            $mensaje = "✅ Producto y lote registrados correctamente.";
            $exito = true;
        } else {
            $mensaje = "⚠️ Producto registrado, pero error al crear lote.";
        }
    } else {
        $mensaje = "❌ Error al registrar producto.";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Agregar Producto y Lote - Farvec</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
  --verde:#16a34a; --verde-osc:#15803d; --verde-claro:#22c55e;
  --rojo:#dc2626; --amarillo:#f59e0b; --azul:#2563eb;
  --gris:#f9fafb; --borde:#e5e7eb; --texto:#111827; --muted:#6b7280;
  --card:#ffffff; --card-2:#f8fafc;
  --shadow: 0 10px 25px rgba(0,0,0,.08);
}
*{box-sizing:border-box}
html,body{height:100%;min-height:100vh}
body{
  margin:0; font-family:Segoe UI,system-ui,sans-serif; color:var(--texto);
  background: linear-gradient(130deg, #d9fbe7 0%, #c7f6de 20%, #b9f0df 40%, #c8e8ff 60%, #efe1ff 85%, #f8f9fb 100%);
  background-size: 200% 200%;
  animation: gradientMove 20s ease-in-out infinite;
  position:relative; overflow-x:hidden;
}

/* 💊 Fondo de pastillas animadas (mismo estilo) */
.bg-pastillas{
  position: fixed; inset: 0; z-index: 0; pointer-events:none; opacity:.55;
  background-image:url("data:image/svg+xml,%3Csvg width='160' height='160' viewBox='0 0 160 160' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2316a34a22'%3E%3Cellipse cx='30' cy='30' rx='12' ry='5' transform='rotate(30 30 30)'/%3E%3Cellipse cx='120' cy='25' rx='10' ry='4' transform='rotate(-25 120 25)'/%3E%3Cellipse cx='80' cy='120' rx='9' ry='3.6' transform='rotate(40 80 120)'/%3E%3Crect x='70' y='60' width='18' height='6' rx='3' transform='rotate(45 70 60)'/%3E%3Ccircle cx='54' cy='140' r='5'/%3E%3Ccircle cx='140' cy='90' r='4'/%3E%3C/g%3E%3C/svg%3E");
  background-size: 180px 180px;
  animation:pillsMove 38s linear infinite alternate;
}
@keyframes pillsMove{
  0%{background-position:0 0}
  100%{background-position:240px 220px}
}

/* Topbar (estructura respetada, solo estilo) */
.topbar{
  display:flex;align-items:center;gap:12px;padding:14px 18px;
  position:sticky;top:0;z-index:5;
  backdrop-filter:saturate(1.1) blur(6px);
}
.topbar-inner{
  width:100%;display:flex;align-items:center;gap:14px;
  background: linear-gradient(180deg, #ffffffcc, #ffffff99);
  border:1px solid var(--borde); border-radius:14px; padding:10px 12px;
  box-shadow: var(--shadow);
  animation: slideDown .6s ease;
}
.back{
  background:linear-gradient(180deg, var(--verde) 0%, var(--verde-osc) 100%);
  color:#fff; border:none; padding:10px 14px; border-radius:12px; cursor:pointer;
  box-shadow:0 10px 20px rgba(34,197,94,.25); transition:transform .2s, filter .2s;
}
.back:hover{ transform: translateY(-1px) scale(1.02); filter:brightness(1.02); }
.h1{display:flex;align-items:center;gap:10px;font-size:22px;color:#0f5132;font-weight:800}
.h1 i{color:var(--verde-osc); animation:pulse 2.2s ease-in-out infinite}
.flex-spacer{flex:1}

/* Panel/Card principal */
.panel{
  max-width:1100px; margin:18px auto; background:linear-gradient(180deg, var(--card) 0%, var(--card-2) 100%);
  border:1px solid var(--borde); border-radius:18px; box-shadow: var(--shadow);
  padding:20px; animation: fadeInUp .7s ease both;
  position:relative; overflow:hidden;
}
.panel::after{
  content:""; position:absolute; right:-40px; top:-40px; width:160px; height:160px; border-radius:50%;
  background: radial-gradient(#22c55e22, transparent 60%);
  animation: pulseBlob 4s ease-in-out infinite;
}
@keyframes pulseBlob{0%,100%{transform:scale(1)}50%{transform:scale(1.08)}}

/* Secciones del formulario */
.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:22px}
fieldset{
  margin:0; border:1px dashed #dfe7ee; padding:18px; border-radius:14px; background:#ffffffd9;
  transition:transform .25s ease, box-shadow .25s ease;
}
fieldset:hover{ transform: translateY(-2px); box-shadow:0 12px 24px rgba(0,0,0,.06) }
legend{
  padding:0 10px; font-weight:800; font-size:14px; color:var(--verde-osc);
  background:#eafff2; border:1px solid #c3f8d3; border-radius:999px; display:inline-block; line-height:28px; height:28px;
}

/* Campos */
label{display:block;font-size:12px;margin:10px 0 6px;color:var(--muted);font-weight:700;letter-spacing:.2px;text-transform:uppercase}
input,select{
  width:100%; padding:12px 14px; border:1px solid var(--borde); border-radius:12px;
  outline:none; font-size:14px; background:#fff; color:var(--texto);
  transition: border-color .2s, box-shadow .2s, transform .08s;
}
input:focus, select:focus{
  border-color: var(--verde-claro);
  box-shadow: 0 0 0 4px rgba(34,197,94,.18);
}
input:hover, select:hover{ transform: translateY(-1px) }
select{ appearance:none; background-image:linear-gradient(45deg, transparent 50%, #999 50%), linear-gradient(135deg, #999 50%, transparent 50%);
  background-position: calc(100% - 18px) calc(1.1em), calc(100% - 13px) calc(1.1em);
  background-size:5px 5px, 5px 5px; background-repeat:no-repeat;
}

.check{margin-top:12px;display:flex;align-items:center;gap:8px;font-size:14px}
.check input[type="checkbox"]{
  width:18px;height:18px;border-radius:6px;border:1px solid var(--borde); appearance:none; display:grid; place-items:center;
  background:#fff; cursor:pointer; transition:.2s;
}
.check input[type="checkbox"]:checked{
  background:var(--verde); border-color:var(--verde);
}
.check input[type="checkbox"]::after{
  content:"\f00c"; font: normal 12px/1 "Font Awesome 6 Free"; font-weight:900; color:#fff; opacity:0; transform:scale(.6);
  transition:.15s;
}
.check input[type="checkbox"]:checked::after{opacity:1; transform:scale(1)}

/* Botón Guardar */
.btn-add{
  grid-column:1/-1; margin-top:8px;
  background:linear-gradient(90deg, var(--verde-osc), var(--verde));
  color:#fff;border:none;padding:14px 16px;font-size:15px;border-radius:12px;cursor:pointer;
  display:flex;align-items:center;justify-content:center;gap:10px;
  box-shadow:0 14px 28px rgba(21,128,61,.25);
  transition: transform .2s, box-shadow .2s;
  position:relative; overflow:hidden;
}
.btn-add:hover{ transform: translateY(-2px); box-shadow:0 18px 36px rgba(21,128,61,.28) }
.btn-add .shine{
  content:""; position:absolute; inset:0; background:linear-gradient(120deg, transparent 0%, #ffffff33 30%, transparent 60%);
  transform: translateX(-120%); transition: transform .6s ease;
}
.btn-add:hover .shine{ transform: translateX(120%) }

/* Alertas con micro-animaciones */
.alert-success,.alert-error{
  max-width:1100px;margin:16px auto;padding:14px 16px;border-radius:12px;font-weight:600;
  border:1px solid transparent; display:flex; align-items:center; gap:10px;
  animation: fadeIn .6s ease;
}
.alert-success{background:#e7fff0;border-color:#8df0b3;color:#166534; box-shadow:0 6px 18px rgba(22,101,52,.08)}
.alert-error{background:#ffecec;border-color:#ffb4b4;color:#991b1b; box-shadow:0 6px 18px rgba(153,27,27,.08)}
.alert-success i{color:#16a34a}
.alert-error i{color:#dc2626}

/* Footer */
.footer{text-align:center;color:var(--muted);font-size:12px;margin:22px 0;animation:fadeIn 1.1s ease}

/* Preferencia de usuario para reducir motion */
@media (prefers-reduced-motion: reduce){
  *{animation:none!important;transition:none!important}
}

/* Animaciones base */
@keyframes gradientMove{0%{background-position:0% 0%}50%{background-position:100% 100%}100%{background-position:0% 0%}}
@keyframes fadeIn{from{opacity:0} to{opacity:1}}
@keyframes fadeInUp{from{opacity:0; transform:translateY(18px)} to{opacity:1; transform:none}}
@keyframes slideDown{from{opacity:0; transform:translateY(-14px)} to{opacity:1; transform:none}}
@keyframes pulse{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}

/* Pequeño tooltip del botón Volver (opcional, sin cambiar estructura) */
.back[data-tip]{
  position:relative;
}
.back[data-tip]:hover::after{
  content:attr(data-tip);
  position:absolute; top:110%; left:0; white-space:nowrap;
  background:#0f172a; color:#e5e7eb; padding:6px 10px; border-radius:8px; font-size:12px;
  box-shadow:0 8px 16px rgba(0,0,0,.2);
}
</style>
</head>
<body>
<div class="bg-pastillas" aria-hidden="true"></div>

<!-- TOPBAR -->
<div class="topbar">
  <div class="topbar-inner">
    <a href="Stock.php">
      <button class="back" data-tip="Volver a la lista">
        <i class="fa-solid fa-arrow-left"></i> Volver al Stock
      </button>
    </a>
    <div class="h1"><i class="fa-solid fa-circle-plus"></i> Agregar Producto y Lote</div>
    <div class="flex-spacer"></div>
    <!-- espacio para futuras acciones -->
  </div>
</div>

<?php if (!empty($mensaje)): ?>
  <div class="<?= $exito ? 'alert-success' : 'alert-error' ?>">
    <i class="fa-solid <?= $exito ? 'fa-circle-check' : 'fa-circle-exclamation' ?>"></i>
    <?= htmlspecialchars($mensaje) ?>
  </div>
<?php endif; ?>

<!-- FORM -->
<form method="POST" class="panel form-grid">
  <fieldset>
    <legend>Datos del Producto</legend>

    <label>Nombre</label>
    <input type="text" name="nombre" required>

    <label>Precio</label>
    <input type="number" step="0.01" name="precio" required>

    <label>Stock Mínimo</label>
    <input type="number" name="stock_minimo" required>

    <label>Categoría</label>
    <select name="categoria_id" required>
      <option value="">Seleccione...</option>
      <?php while ($c = $categorias->fetch_assoc()): ?>
        <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre']) ?></option>
      <?php endwhile; ?>
    </select>

    <div class="check">
      <input type="checkbox" name="requiere_receta" id="req">
      <label for="req">Requiere receta</label>
    </div>
  </fieldset>

  <fieldset>
    <legend>Datos del Lote</legend>

    <label>Número de Lote</label>
    <input type="text" name="numero_lote" required>

    <label>Fecha de Vencimiento</label>
    <input type="date" name="fecha_vencimiento" required>

    <label>Cantidad Inicial</label>
    <input type="number" name="cantidad_inicial" required>
  </fieldset>

  <button type="submit" class="btn-add">
    <span class="shine"></span>
    <i class="fa-solid fa-floppy-disk"></i> Guardar
  </button>
</form>

<div class="footer">Farvec • Stock • <?= date('Y') ?></div>

<script>
/* Pequeño efecto “ripple” en el botón Guardar (sin dependencias) */
document.addEventListener('click', function(e){
  const btn = e.target.closest('.btn-add');
  if(!btn) return;
  const circle = document.createElement('span');
  const d = Math.max(btn.clientWidth, btn.clientHeight);
  circle.style.width = circle.style.height = d + 'px';
  circle.style.position = 'absolute';
  circle.style.left = (e.clientX - btn.getBoundingClientRect().left - d/2) + 'px';
  circle.style.top  = (e.clientY - btn.getBoundingClientRect().top - d/2) + 'px';
  circle.style.borderRadius = '50%';
  circle.style.background = 'rgba(255,255,255,.35)';
  circle.style.transform = 'scale(0)';
  circle.style.animation = 'ripple .6s ease-out forwards';
  btn.appendChild(circle);
  setTimeout(()=>circle.remove(), 650);
});
/* keyframes del ripple por JS para no tocar el CSS base */
(function addRippleCSS(){
  const css = document.createElement('style');
  css.textContent = "@keyframes ripple{to{transform:scale(2.8);opacity:0}}";
  document.head.appendChild(css);
})();
</script>
</body>
</html>

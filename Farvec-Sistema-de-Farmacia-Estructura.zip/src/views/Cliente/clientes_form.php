<?php
session_start();
require_once 'Conexion.php';
require_once 'ControladorClientes.php';

if (!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit(); }

$conn = new Conexion();
$ctl = new ControladorClientes($conn->conexion);
$id = $_GET['id'] ?? null;
$cliente = $id ? $ctl->obtener((int)$id) : null;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title><?= $id ? 'Editar Cliente' : 'Nuevo Cliente' ?> - FARVEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root {
  --verde:#16a34a; --verde-osc:#15803d; --blanco:#fff;
}

/* 🎨 Fondo con color verde original */
body {
  font-family:"Segoe UI",system-ui;
  background:linear-gradient(180deg,#b4f8c8,#c2fbd7,#d7fbe8,#e5fff5);
  background-attachment:fixed;
  min-height:100vh;
  overflow-x:hidden;
  position:relative;
  color:#111827;
}

/* 💊 Capa de pastillas animadas (sin tapar el color de fondo) */
.bg-pastillas {
  position:fixed;
  inset:0;
  z-index:0;
  pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg width='160' height='160' viewBox='0 0 160 160' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2316a34a22'%3E%3Cellipse cx='30' cy='30' rx='12' ry='5' transform='rotate(30 30 30)'/%3E%3Cellipse cx='120' cy='25' rx='10' ry='4' transform='rotate(-25 120 25)'/%3E%3Cellipse cx='80' cy='120' rx='9' ry='3.6' transform='rotate(40 80 120)'/%3E%3Crect x='70' y='60' width='18' height='6' rx='3' transform='rotate(45 70 60)'/%3E%3Ccircle cx='54' cy='140' r='5'/%3E%3Ccircle cx='140' cy='90' r='4'/%3E%3C/g%3E%3C/svg%3E");
  background-size:180px 180px;
  animation:pillsMove 40s linear infinite alternate;
  opacity:.4;
}
@keyframes pillsMove {
  0% {background-position:0 0;}
  100% {background-position:240px 220px;}
}

/* 🧾 Tarjeta del formulario */
.card {
  background:var(--blanco);
  border:none;
  border-radius:18px;
  box-shadow:0 8px 20px rgba(0,0,0,.1);
  animation: fadeIn .6s ease-out;
  position:relative;
  z-index:1;
}
@keyframes fadeIn {
  from{opacity:0;transform:translateY(15px);}
  to{opacity:1;transform:none;}
}

/* Botones */
.btn-farvec {
  background-color:var(--verde);
  color:white;
  border:none;
  font-weight:600;
  box-shadow:0 6px 14px rgba(0,168,107,.25);
  transition:.3s;
}
.btn-farvec:hover {
  background-color:var(--verde-osc);
  transform:translateY(-2px);
}
.btn-volver {
  background-color:var(--verde-osc);
  color:white;
  border:none;
  font-weight:600;
  border-radius:8px;
  padding:8px 14px;
  transition:.3s;
  z-index:1;
  position:relative;
}
.btn-volver:hover {
  background-color:#00885a;
  transform:translateY(-2px);
}
</style>
</head>
<body>
<div class="bg-pastillas" aria-hidden="true"></div>

<!-- Botón Volver -->
<div class="p-3">
  <button class="btn-volver" onclick="location.href='clientes_listar.php'">
    <i class="fa-solid fa-arrow-left"></i> Volver
  </button>
</div>

<!-- FORMULARIO -->
<div class="container py-4">
  <div class="card p-4 mx-auto" style="max-width:600px;">
    <h3 class="text-center text-success mb-4">
      <i class="fa-solid fa-user-plus"></i> <?= $id ? 'Editar Cliente' : 'Nuevo Cliente' ?>
    </h3>

    <form method="post" action="clientes_guardar.php">
      <input type="hidden" name="id" value="<?= $cliente['id'] ?? '' ?>">

      <div class="mb-3">
        <label class="form-label">Nombre</label>
        <input type="text" name="nombre" class="form-control" required value="<?= $cliente['nombre'] ?? '' ?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Apellido</label>
        <input type="text" name="apellido" class="form-control" required value="<?= $cliente['apellido'] ?? '' ?>">
      </div>

      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">Tipo Documento</label>
          <select name="tipoDocumento" class="form-select" required>
            <?php
            $tipos = ['DNI','CUIT','CUIL'];
            foreach($tipos as $t){
              $sel = ($cliente['tipoDocumento'] ?? '') === $t ? 'selected' : '';
              echo "<option $sel>$t</option>";
            }
            ?>
          </select>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Número</label>
          <input type="text" name="nroDocumento" class="form-control" required value="<?= $cliente['nroDocumento'] ?? '' ?>">
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Teléfono</label>
        <input type="text" name="telefono" class="form-control" value="<?= $cliente['telefono'] ?? '' ?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= $cliente['email'] ?? '' ?>">
      </div>

      <div class="mb-3">
        <label class="form-label">Dirección</label>
        <input type="text" name="direccion" class="form-control" value="<?= $cliente['direccion'] ?? '' ?>">
      </div>

      <div class="text-center">
        <button type="submit" class="btn btn-farvec"><i class="fa-solid fa-floppy-disk"></i> Guardar</button>
        <a href="clientes_listar.php" class="btn btn-secondary ms-2"><i class="fa-solid fa-xmark"></i> Cancelar</a>
      </div>
    </form>
  </div>
</div>
</body>
</html>

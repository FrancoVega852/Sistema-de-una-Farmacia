<?php
session_start();
require_once 'Conexion.php';
require_once 'ControladorClientes.php';

if (!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit(); }

$conn = new Conexion();
$ctl = new ControladorClientes($conn->conexion);
$clientes = $ctl->listar();

// Totales
$total = $conn->conexion->query("SELECT COUNT(*) AS c FROM Cliente")->fetch_assoc()['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Gestión de Clientes - FARVEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<style>
:root{
  --verde:#16a34a; --verde-osc:#15803d; --verde-claro:#22c55e;
  --borde:#e5e7eb; --texto:#111827; --gris:#f9fafb;
  --card:#ffffff; --shadow:0 10px 25px rgba(0,0,0,.08);
}
body{
  font-family:"Segoe UI",system-ui;
  background:linear-gradient(180deg,#b4f8c8,#c2fbd7,#d7fbe8,#e5fff5);
  background-attachment:fixed;
  min-height:100vh;overflow-x:hidden;position:relative;
}
.bg-pastillas{
  position:fixed;inset:0;z-index:0;pointer-events:none;
  background-image:url("data:image/svg+xml,%3Csvg width='160' height='160' viewBox='0 0 160 160' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2316a34a22'%3E%3Cellipse cx='30' cy='30' rx='12' ry='5' transform='rotate(30 30 30)'/%3E%3Cellipse cx='120' cy='25' rx='10' ry='4' transform='rotate(-25 120 25)'/%3E%3Cellipse cx='80' cy='120' rx='9' ry='3.6' transform='rotate(40 80 120)'/%3E%3Crect x='70' y='60' width='18' height='6' rx='3' transform='rotate(45 70 60)'/%3E%3Ccircle cx='54' cy='140' r='5'/%3E%3Ccircle cx='140' cy='90' r='4'/%3E%3C/g%3E%3C/svg%3E");
  background-size:180px 180px;animation:pillsMove 40s linear infinite alternate;opacity:.4;
}
@keyframes pillsMove{0%{background-position:0 0}100%{background-position:240px 220px}}

.container{
  position:relative;z-index:1;max-width:1150px;margin:20px auto;padding:24px;
  background:linear-gradient(180deg,var(--card) 0%,#f9fdfb 100%);
  border-radius:18px;box-shadow:var(--shadow);animation:fadeIn .7s ease;
}
@keyframes fadeIn{from{opacity:0;transform:translateY(10px)}to{opacity:1;transform:none}}

.btn-verde{
  background:linear-gradient(90deg,var(--verde-osc),var(--verde));
  color:white;border:none;padding:8px 16px;border-radius:10px;font-weight:600;
  box-shadow:0 6px 14px rgba(21,128,61,.25);transition:transform .25s ease;
}
.btn-verde:hover{transform:translateY(-2px);filter:brightness(1.05)}

.table-hover tbody tr:hover{background:#f0fdf4;}
td,th{text-align:center;vertical-align:middle;}

.badge-cc{background:#e0f7ef;color:#047857;font-weight:700;border-radius:8px;padding:4px 8px;font-size:12px}
.badge-cc.neg{background:#fee2e2;color:#991b1b}

.footer{text-align:center;color:#555;margin-top:20px;font-size:13px}
</style>
</head>
<body>
<div class="bg-pastillas" aria-hidden="true"></div>

<!-- ENCABEZADO -->
<div class="d-flex align-items-center justify-content-between px-4 pt-4">
  <button class="btn-verde" onclick="location.href='Menu.php'">
    <i class="fa-solid fa-arrow-left"></i> Volver al Menú
  </button>
  <h2 class="fw-bold text-success"><i class="fa-solid fa-users"></i> Gestión de Clientes</h2>
  <a href="clientes_form.php" class="btn-verde"><i class="fa-solid fa-user-plus"></i> Nuevo Cliente</a>
</div>

<div class="container mt-3">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <h5 class="mb-1 text-success">Total de clientes registrados: <?= $total ?></h5>
      <small class="text-muted">Administra clientes, cuentas corrientes y su historial de compras.</small>
    </div>
    <div>
      <button class="btn btn-outline-success btn-sm" onclick="exportar('excel')"><i class="fa-solid fa-file-excel"></i> Excel</button>
      <button class="btn btn-outline-danger btn-sm" onclick="exportar('pdf')"><i class="fa-solid fa-file-pdf"></i> PDF</button>
    </div>
  </div>

  <!-- BUSCADOR -->
  <div class="input-group mb-3">
    <span class="input-group-text bg-success text-white"><i class="fa-solid fa-magnifying-glass"></i></span>
    <input type="text" id="buscar" class="form-control" placeholder="Buscar cliente por nombre, documento o correo...">
  </div>

  <!-- TABLA -->
  <div class="table-responsive">
    <table class="table table-hover align-middle" id="tablaClientes">
      <thead class="table-success">
        <tr>
          <th>ID</th>
          <th>Nombre</th>
          <th>Documento</th>
          <th>Teléfono</th>
          <th>Email</th>
          <th>Cuenta Corriente</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody>
        <?php while($c = $clientes->fetch_assoc()): ?>
        <?php
          $cuenta = $conn->conexion->query("SELECT saldo_actual, limite_credito FROM CuentaCorriente WHERE cliente_id=".$c['id'])->fetch_assoc();
          $saldo = $cuenta['saldo_actual'] ?? 0;
          $limite = $cuenta['limite_credito'] ?? 0;
        ?>
        <tr>
          <td><?= $c['id'] ?></td>
          <td><b><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></b></td>
          <td><?= $c['tipoDocumento'].' '.$c['nroDocumento'] ?></td>
          <td><?= $c['telefono'] ?></td>
          <td><?= $c['email'] ?></td>
          <td>
            <?php if($limite>0): ?>
              <?php if($saldo>=$limite): ?>
                <span class="badge-cc neg">Excedido ($<?= number_format($saldo,2) ?>)</span>
              <?php else: ?>
                <span class="badge-cc">Saldo $<?= number_format($saldo,2) ?></span>
              <?php endif; ?>
            <?php else: ?>
              <small class="text-muted">Sin cuenta</small>
            <?php endif; ?>
          </td>
          <td>
            <button class="btn btn-sm btn-outline-success" onclick="abrirHistorial(<?= $c['id'] ?>)">
              <i class="fa-solid fa-file-invoice"></i>
            </button>
            <button class="btn btn-sm btn-outline-primary" onclick="location.href='clientes_form.php?id=<?= $c['id'] ?>'">
              <i class="fa-solid fa-pen"></i>
            </button>
            <button class="btn btn-sm btn-outline-danger" onclick="if(confirm('¿Eliminar cliente?')) location.href='clientes_eliminar.php?id=<?= $c['id'] ?>'">
              <i class="fa-solid fa-trash"></i>
            </button>
          </td>
        </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  </div>

  <div class="footer">FARVEC • Módulo de Clientes • <?= date('Y') ?></div>
</div>

<!-- MODAL HISTORIAL -->
<div class="modal fade" id="modalHistorial" tabindex="-1">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-success text-white">
        <h5 class="modal-title"><i class="fa-solid fa-file-invoice"></i> Historial de Compras</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="historialContenido" class="text-center text-muted">Cargando...</div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Búsqueda en vivo
document.getElementById('buscar').addEventListener('keyup',()=>{
  const q = document.getElementById('buscar').value.toLowerCase();
  document.querySelectorAll('#tablaClientes tbody tr').forEach(tr=>{
    const text = tr.textContent.toLowerCase();
    tr.style.display = text.includes(q) ? '' : 'none';
  });
});

// Historial de compras (AJAX)
function abrirHistorial(id){
  const modal = new bootstrap.Modal(document.getElementById('modalHistorial'));
  document.getElementById('historialContenido').innerHTML = 'Cargando...';
  fetch('clientes_historial.php?id='+id)
    .then(r=>r.text())
    .then(html=>{
      document.getElementById('historialContenido').innerHTML = html || '<p>Sin registros de compras</p>';
    });
  modal.show();
}

// Exportar (placeholder)
function exportar(tipo){
  if(tipo === 'excel'){
    const tabla = document.getElementById('tablaClientes').outerHTML;
    const data = new Blob([tabla], {type: 'application/vnd.ms-excel'});
    const url = URL.createObjectURL(data);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'clientes_farvec.xls';
    a.click();
  }
  else if(tipo === 'pdf'){
    window.print(); // versión simple: imprime en PDF
  }
}



</script>
</body>
</html>

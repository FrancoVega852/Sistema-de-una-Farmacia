<?php
session_start();
require_once 'Conexion.php';
require_once 'ControladorClientes.php';

if (!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit(); }

$conn = new Conexion();
$ctl = new ControladorClientes($conn->conexion);

$id = $_POST['id'] ?? null;
$ctl->guardar($id ? (int)$id : null, $_POST);

header("Location: clientes_listar.php");
exit;
?>

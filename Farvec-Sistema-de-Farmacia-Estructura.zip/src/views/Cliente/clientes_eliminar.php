<?php
session_start();
require_once 'Conexion.php';
require_once 'ControladorClientes.php';

if (!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit(); }

$conn = new Conexion();
$ctl = new ControladorClientes($conn->conexion);

$id = $_GET['id'] ?? null;
if ($id) $ctl->eliminar((int)$id);

header("Location: clientes_listar.php");
exit;
?>

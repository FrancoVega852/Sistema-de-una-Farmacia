<?php
session_start();
require_once 'Conexion.php';

if (!isset($_SESSION['usuario_id'])) { header("Location: login.php"); exit(); }

$conn = new Conexion();
$db = $conn->conexion;

// --- Reporte de Ventas (últimos 15 días) ---
$ventasQuery = "
SELECT DATE(fecha) AS dia, SUM(total) AS total, COUNT(*) AS tickets
FROM Venta
WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 15 DAY)
GROUP BY DATE(fecha)
ORDER BY dia ASC";
$ventas = $db->query($ventasQuery)->fetch_all(MYSQLI_ASSOC);

// --- Top 10 Productos Más Vendidos ---
$topQuery = "
SELECT p.nombre, c.nombre AS categoria, SUM(dv.cantidad) AS unidades, SUM(dv.subtotal) AS total
FROM DetalleVenta dv
JOIN Producto p ON p.id = dv.producto_id
LEFT JOIN Categoria c ON c.id = p.categoria_id
GROUP BY p.id
ORDER BY unidades DESC
LIMIT 10";
$top = $db->query($topQuery)->fetch_all(MYSQLI_ASSOC);

// --- Productos con Stock Bajo ---
$stockBajo = $db->query("
SELECT id, nombre, stock_actual, stock_minimo
FROM Producto
WHERE stock_actual <= stock_minimo
ORDER BY stock_actual ASC
LIMIT 10
")->fetch_all(MYSQLI_ASSOC);

// --- Lotes Próximos a Vencer (≤ 30 días) ---
$vencimientos = $db->query("
SELECT p.nombre, l.numero_lote, l.fecha_vencimiento, l.cantidad_actual
FROM Lote l
JOIN Producto p ON p.id=l.producto_id
WHERE l.fecha_vencimiento <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)
ORDER BY l.fecha_vencimiento ASC
")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Reportes - FARVEC</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1"></script>

<style>
:root{
  --verde:#16a34a;
  --verde-osc:#15803d;
  --verde-claro:#22c55e;
  --gris:#f9fafb;
}

/* === FONDO === */
html{
  height:100%;
  background: linear-gradient(180deg,#e6fff6,#c8fff0,#b2f0df,#d7fff4);
  background-size: 400% 400%;
  background-attachment: fixed;
  animation: htmlFlow 20s ease-in-out infinite;
}
@keyframes htmlFlow{
  0%{background-position:0% 50%;}
  50%{background-position:100% 50%;}
  100%{background-position:0% 50%;}
}

body{
  font-family:"Segoe UI",system-ui;
  margin:0;
  background:transparent;
  overflow-x:hidden;
}
body::before{
  content:"";
  position:fixed; inset:0; z-index:0;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cg fill='%2316a34a22'%3E%3Cellipse cx='30' cy='40' rx='12' ry='5' transform='rotate(25 30 40)'/%3E%3Cellipse cx='130' cy='130' rx='10' ry='4' transform='rotate(-25 130 130)'/%3E%3Ccircle cx='60' cy='90' r='3'/%3E%3C/g%3E%3C/svg%3E");
  background-size:180px 180px;
  animation:pillsMove 50s linear infinite alternate;
  opacity:.4;
  pointer-events:none;
}
@keyframes pillsMove{
  0%{background-position:0 0;}
  100%{background-position:400px 300px;}
}

/* === CONTENEDOR === */
.container-report{
  position:relative; z-index:1;
  max-width:1250px;
  margin:50px auto;
  padding:36px;
  background:rgba(255,255,255,0.96);
  border-radius:24px;
  box-shadow:0 15px 40px rgba(0,0,0,.15);
  backdrop-filter:blur(10px);
  animation: fadeIn .8s ease both;
}
@keyframes fadeIn{from{opacity:0;transform:translateY(20px);}to{opacity:1;transform:none;}}

/* === HEADER === */
.header-actions{
  display:flex;
  justify-content:space-between;
  align-items:center;
  margin-bottom:25px;
  position:relative;
}
.header-actions h2{
  position:absolute;
  left:50%;
  transform:translateX(-50%);
  margin:0;
}
.btn-verde{
  background:linear-gradient(90deg,var(--verde-osc),var(--verde));
  color:#fff;border:none;padding:10px 18px;border-radius:10px;font-weight:600;
  box-shadow:0 6px 14px rgba(21,128,61,.25);
  transition:all .25s ease;
}
.btn-verde:hover{transform:translateY(-2px);filter:brightness(1.05);}
.btn-outline-success:hover{transform:translateY(-2px);}

/* === TARJETAS DE RESUMEN === */
.resumen{
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(230px,1fr));
  gap:16px;
  margin-bottom:30px;
}
.card-resumen{
  background:linear-gradient(180deg,#ffffff 0%,#f9fefb 100%);
  border:1px solid #e5e7eb;
  border-radius:16px;
  padding:18px;
  display:flex;align-items:center;gap:14px;
  box-shadow:0 8px 20px rgba(0,0,0,.08);
  transition:all .3s ease;
}
.card-resumen:hover{transform:translateY(-5px);box-shadow:0 15px 35px rgba(0,0,0,.12);}
.card-resumen i{font-size:30px;color:var(--verde);}
.card-resumen .text-muted{font-size:13px;margin:0;}
.card-resumen h4{margin:0;font-weight:700;color:#1f2937;}

/* === TABLAS === */
.table th,.table td{text-align:center;vertical-align:middle;}
.table-hover tbody tr:hover{background:#f0fdf4;}
section{margin-bottom:35px;animation:sectionUp .6s ease both;}
@keyframes sectionUp{from{opacity:0;transform:translateY(15px);}to{opacity:1;transform:none;}}

/* === BOTÓN IMPRIMIR FIJO === */
.btn-float-print{
  position:fixed;
  bottom:25px;right:30px;
  background:#16a34a;
  color:white;
  border:none;
  border-radius:50%;
  width:55px;height:55px;
  box-shadow:0 10px 25px rgba(22,163,74,.4);
  cursor:pointer;
  transition:.3s;
  z-index:5;
}
.btn-float-print:hover{transform:scale(1.1);background:#15803d;}
.btn-float-print i{font-size:22px;}
</style>
</head>
<body>

<div class="container-report">
  <!-- ENCABEZADO -->
  <div class="header-actions">
    <button type="button" class="btn-verde" onclick="location.href='Menu.php'">
      <i class="fa-solid fa-arrow-left"></i> Volver al Menú
    </button>
    <h2 class="fw-bold text-success"><i class="fa-solid fa-chart-line"></i> Reportes Generales</h2>
  </div>

  <!-- TARJETAS RESUMEN -->
  <div class="resumen">
    <div class="card-resumen"><i class="fa-solid fa-sack-dollar"></i>
      <div><p class="text-muted mb-1">Total Vendido (15 días)</p>
      <h4>$<?= number_format(array_sum(array_column($ventas,'total')),2,',','.') ?></h4></div>
    </div>
    <div class="card-resumen"><i class="fa-solid fa-receipt"></i>
      <div><p class="text-muted mb-1">Tickets Emitidos</p>
      <h4><?= array_sum(array_column($ventas,'tickets')) ?></h4></div>
    </div>
    <div class="card-resumen"><i class="fa-solid fa-boxes-stacked"></i>
      <div><p class="text-muted mb-1">Productos con Stock Bajo</p>
      <h4><?= count($stockBajo) ?></h4></div>
    </div>
    <div class="card-resumen"><i class="fa-solid fa-hourglass-half"></i>
      <div><p class="text-muted mb-1">Lotes por Vencer</p>
      <h4><?= count($vencimientos) ?></h4></div>
    </div>
  </div>

  <!-- 📈 Reporte de Ventas -->
  <section>
    <h4 class="text-success mb-3"><i class="fa-solid fa-chart-column"></i> Ventas de los últimos 15 días</h4>
    <canvas id="ventasChart" height="100"></canvas>
  </section>

  <!-- 🏆 Top Productos -->
  <section>
    <h4 class="text-success mb-3"><i class="fa-solid fa-pills"></i> Top 10 Productos Más Vendidos</h4>
    <canvas id="topChart" height="120"></canvas>
  </section>

  <!-- ⚠️ Alertas -->
  <section>
    <h4 class="text-success mb-3"><i class="fa-solid fa-triangle-exclamation"></i> Alertas de Stock y Vencimientos</h4>
    <div class="row">
      <div class="col-md-6">
        <h6 class="text-danger"><i class="fa-solid fa-box"></i> Stock Bajo</h6>
        <table class="table table-sm table-hover align-middle shadow-sm rounded">
          <thead class="table-danger"><tr><th>Producto</th><th>Stock</th><th>Mínimo</th></tr></thead>
          <tbody>
            <?php if(!$stockBajo): ?><tr><td colspan="3">Sin alertas 👌</td></tr><?php endif; ?>
            <?php foreach($stockBajo as $p): ?>
            <tr><td><?= $p['nombre'] ?></td><td><?= $p['stock_actual'] ?></td><td><?= $p['stock_minimo'] ?></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="col-md-6">
        <h6 class="text-warning"><i class="fa-solid fa-hourglass-half"></i> Próximos a Vencer</h6>
        <table class="table table-sm table-hover align-middle shadow-sm rounded">
          <thead class="table-warning"><tr><th>Producto</th><th>Lote</th><th>Vence</th><th>Cant.</th></tr></thead>
          <tbody>
            <?php if(!$vencimientos): ?><tr><td colspan="4">Sin vencimientos próximos 👌</td></tr><?php endif; ?>
            <?php foreach($vencimientos as $l): ?>
            <tr><td><?= $l['nombre'] ?></td><td><?= $l['numero_lote'] ?></td><td><?= $l['fecha_vencimiento'] ?></td><td><?= $l['cantidad_actual'] ?></td></tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <div class="text-center mt-4 text-muted">
    FARVEC • Reportes del Sistema · <?= date('Y') ?>
  </div>
</div>

<!-- 🖨️ Botón imprimir flotante -->
<button class="btn-float-print" onclick="window.print()"><i class="fa-solid fa-print"></i></button>

<script>
const ventasData = {
  labels: <?= json_encode(array_column($ventas,'dia')) ?>,
  datasets: [{
    label: 'Ventas ($)',
    data: <?= json_encode(array_column($ventas,'total')) ?>,
    backgroundColor: 'rgba(22,163,74,0.35)',
    borderColor: '#15803d',
    borderWidth: 2,
    tension: 0.3,
    fill: true
  }]
};
new Chart(document.getElementById('ventasChart'), {type:'line',data:ventasData,options:{scales:{y:{beginAtZero:true}}}});

const topData = {
  labels: <?= json_encode(array_column($top,'nombre')) ?>,
  datasets: [{
    label: 'Unidades Vendidas',
    data: <?= json_encode(array_column($top,'unidades')) ?>,
    backgroundColor: 'rgba(22,163,74,0.7)',
    borderColor: '#15803d',
    borderWidth: 1
  }]
};
new Chart(document.getElementById('topChart'), {type:'bar',data:topData,options:{indexAxis:'y',scales:{x:{beginAtZero:true}}}});
</script>
</body>
</html>

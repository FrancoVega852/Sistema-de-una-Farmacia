<?php
session_start();
require_once 'Conexion.php';
require_once 'ControladorCompras.php';

// Verificación de sesión
if (!isset($_SESSION['usuario_id'])) { 
    header("Location: login.php"); 
    exit(); 
}

$conn = new Conexion();
$ctl  = new ControladorCompras($conn->conexion);

// Proveedores
$proveedoresRes = $ctl->proveedores();
$prov_id = isset($_GET['prov']) ? (int)$_GET['prov'] : null;

// Productos
$productosRes  = $ctl->productos($prov_id);
$productos = [];
while($p=$productosRes->fetch_assoc()){
  $productos[] = [
    'id'=>(int)$p['id'],
    'nombre'=>$p['nombre'],
    'presentacion'=>$p['presentacion'] ?? '',
    'precio'=>(float)$p['precio'],
    'stock'=>(int)$p['stock_actual'],
    'min'=>(int)$p['stock_minimo'],
    'categoria'=>$p['categoria'] ?? 'General',
    'asoc'=>(int)$p['asociado'],
    'lote'=>$p['numero_lote'] ?? '',
    'vto'=>$p['fecha_vencimiento'] ?? ''
  ];
}

$sug = $ctl->sugerencias();
$top = $ctl->topVendidos();

// Relación Proveedor-Productos
$mapaProveedores = require 'mapaProveedores.php';
?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Nueva Compra - Farvec</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
:root {
  --verde: #1f7a4d;
  --verde-oscuro: #155c39;
  --fondo: #f4f6f8;
  --blanco: #ffffff;
  --borde: #e1e4e8;
  --gris: #6b7280;
  --texto: #1f2937;
  --acento: #22c55e;
  --sombra: rgba(0,0,0,0.08);
}
* { box-sizing: border-box; font-family: 'Inter', sans-serif; }

/* FONDO estilo Stock y Lotes */
body {
  margin: 0;
  min-height: 100vh;
  background: linear-gradient(135deg, #f7fafc, #eefdf5);
  background-attachment: fixed;
  position: relative;
  color: var(--texto);
  overflow-x: hidden;
}
body::before {
  content: '';
  position: fixed;
  top: 0; left: 0;
  width: 100%; height: 100%;
  background-image:
    radial-gradient(circle at 20% 80%, rgba(0,143,76,0.05) 0%, transparent 50%),
    radial-gradient(circle at 80% 20%, rgba(37,99,235,0.05) 0%, transparent 50%);
  background-size: 600px 600px, 700px 700px;
  background-position: 0px 0px, 300px 300px;
  animation: fondoFlotante 25s ease-in-out infinite;
  z-index: -1;
}
@keyframes fondoFlotante {
  0%,100% { transform: translate(0,0); }
  33% { transform: translate(30px,-15px); }
  66% { transform: translate(-20px,20px); }
}

/* HEADER */
.top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  background: var(--blanco);
  padding: 12px 20px;
  border-bottom: 1px solid var(--borde);
  box-shadow: 0 4px 10px var(--sombra);
  position: sticky;
  top: 0;
  z-index: 10;
}
.top .left {
  display: flex;
  align-items: center;
  gap: 12px;
}
.top h1 {
  margin: 0;
  font-size: 20px;
  color: var(--verde-oscuro);
  display: flex;
  align-items: center;
  gap: 8px;
}
.back {
  background: var(--verde);
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 8px 14px;
  font-weight: 600;
  cursor: pointer;
  transition: background 0.2s;
}
.back:hover { background: var(--verde-oscuro); }

/* MAIN LAYOUT */
.wrap {
  display: grid;
  grid-template-columns: 2fr 1.2fr;
  gap: 20px;
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}
@media (max-width:1100px){ .wrap { grid-template-columns: 1fr; } }

.card {
  background: var(--blanco);
  border: 1px solid var(--borde);
  border-radius: 14px;
  box-shadow: 0 6px 18px var(--sombra);
  overflow: hidden;
  animation: fadeInUp 0.6s ease both;
}
.card-h {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 14px 18px;
  border-bottom: 1px solid var(--borde);
  background: #f9fafb;
  font-weight: 600;
  color: var(--verde-oscuro);
}
.card-b { padding: 16px; }

/* FORM ELEMENTS */
.input, select {
  border: 1px solid var(--borde);
  border-radius: 8px;
  padding: 8px 12px;
  font-size: 14px;
  outline: none;
}
select:focus, .input:focus {
  border-color: var(--verde);
  box-shadow: 0 0 0 2px rgba(34,197,94,0.25);
}
.filters {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-bottom: 10px;
  align-items: center;
}

/* PRODUCT GRID */
.grid {
  display: grid;
  grid-template-columns: repeat(auto-fit,minmax(280px,1fr));
  gap: 14px;
}
.product {
  border: 1px solid var(--borde);
  border-radius: 12px;
  padding: 12px;
  background: var(--blanco);
  display: flex;
  flex-direction: column;
  gap: 8px;
  transition: transform 0.2s ease, box-shadow 0.2s ease;
}
.product:hover {
  transform: scale(1.02);
  box-shadow: 0 8px 18px var(--sombra);
}
.product h4 {
  margin: 0;
  font-size: 16px;
  color: var(--texto);
}
.badge {
  border: 1px solid var(--borde);
  border-radius: 999px;
  padding: 3px 8px;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  gap: 6px;
}
.badge.green { background: #ecfdf5; color: #047857; border-color: #a7f3d0; }
.badge.orange { background: #fff7ed; color: #b45309; border-color: #fed7aa; }

.btn {
  padding: 8px 12px;
  border-radius: 8px;
  border: none;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.2s ease;
}
.btn.primary {
  background: var(--verde);
  color: #fff;
}
.btn.primary:hover { background: var(--verde-oscuro); }

/* CART */
.table {
  width: 100%;
  border-collapse: collapse;
  font-size: 14px;
}
.table th, .table td {
  padding: 10px;
  border-bottom: 1px solid var(--borde);
}
.table th {
  background: #ecfdf5;
  color: var(--verde-oscuro);
}
.kpis { display: grid; grid-template-columns: repeat(2,1fr); gap: 10px; margin-bottom: 12px; }
.kpi {
  background: #f8fafc;
  border: 1px dashed #d1d5db;
  border-radius: 10px;
  padding: 8px 10px;
}

/* Animación */
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>
</head>
<body>

<div class="top">
  <div class="left">
    <button class="back" onclick="location.href='Menu.php'"><i class="fa-solid fa-arrow-left"></i> Menú</button>
    <h1><i class="fa-solid fa-truck"></i> Nueva Compra</h1>
  </div>
</div>

<div class="wrap">

  <!-- Catálogo -->
  <section class="card">
    <div class="card-h">
      <div>Catálogo</div>
      <div style="font-size:13px;color:var(--gris)">
        Proveedor:
        <select id="prov" onchange="cambiarProveedor()">
          <option value="">(Todos)</option>
          <?php while($pr=$proveedoresRes->fetch_assoc()): ?>
            <option value="<?= $pr['id'] ?>" <?= ($prov_id==$pr['id']?'selected':'') ?>>
              <?= htmlspecialchars($pr['razonSocial']) ?>
            </option>
          <?php endwhile; ?>
        </select>
      </div>
    </div>
    <div class="card-b">
      <div class="filters">
        <input id="q" class="input" type="search" placeholder="Buscar producto…">
        <select id="f-cat" class="input">
          <option value="">Todas las categorías</option>
          <?php
            $cats = array_values(array_unique(array_map(fn($r)=>$r['categoria'],$productos)));
            sort($cats);
            foreach($cats as $c) echo '<option>'.htmlspecialchars($c).'</option>';
          ?>
        </select>
        <label><input id="f-asoc" type="checkbox" style="accent-color:var(--verde)"> Asociados</label>
        <label><input id="f-min" type="checkbox" style="accent-color:var(--verde)"> Stock ≤ mínimo</label>
      </div>
      <div id="grid" class="grid"></div>
    </div>
  </section>

  <!-- Carrito -->
  <section class="card">
    <div class="card-h">
      <strong>Carrito</strong>
      <span style="font-size:13px;color:var(--gris)">Costo + lote/vencimiento opcionales</span>
    </div>
    <div class="card-b">
      <div class="kpis">
        <div class="kpi"><div style="font-size:13px;color:var(--gris)">Proveedor</div>
          <div id="prov-name"><em><?= $prov_id ? '' : 'Sin seleccionar' ?></em></div></div>
        <div class="kpi"><div style="font-size:13px;color:var(--gris)">Obs.</div>
          <input id="obs" class="input" placeholder="Observaciones (opcional)"></div>
      </div>

      <div style="overflow:auto;max-height:420px;border:1px solid var(--borde);border-radius:10px">
        <table class="table" id="cart">
          <thead>
            <tr>
              <th>Producto</th><th>Presentación</th><th>Categoría</th><th>Precio Base</th>
              <th>Cant</th><th>Costo</th><th>Lote</th><th>Venc.</th><th>Subtotal</th><th>Acción</th>
            </tr>
          </thead>
          <tbody id="cart-body">
            <tr id="empty"><td colspan="10" style="text-align:center;color:#6b7280;padding:14px">Agrega productos desde el catálogo ➜</td></tr>
          </tbody>
        </table>
      </div>

      <div style="display:flex;align-items:center;gap:10px;margin-top:10px;justify-content:flex-end">
        <div style="font-size:15px;color:var(--gris)">Total:</div>
        <div id="total" style="font-weight:800;font-size:18px">$0,00</div>
        <form id="f" method="POST" action="compras_guardar.php" style="display:flex;gap:8px">
          <input type="hidden" name="proveedor_id" id="hid-proveedor">
          <input type="hidden" name="obs" id="hid-obs">
          <div id="hid-lines"></div>
          <button id="btn-save" class="btn primary" disabled><i class="fa-solid fa-floppy-disk"></i> Registrar Compra</button>
        </form>
      </div>
    </div>
  </section>
</div>

<script>
const CATALOGO = <?= json_encode($productos, JSON_UNESCAPED_UNICODE) ?>;
const MAPA_PROV = <?= json_encode($mapaProveedores) ?>;
const PROV_ID = <?= $prov_id ?? 'null' ?>;
const fmt = n => n.toLocaleString('es-AR',{minimumFractionDigits:2, maximumFractionDigits:2});
const $  = s => document.querySelector(s);

const provSel = $('#prov'), provName = $('#prov-name'), hidProv = $('#hid-proveedor');
function cambiarProveedor(){ const v = provSel.value; location.href='compras.php'+(v?`?prov=${v}`:''); }
if (provSel.value){ provName.textContent = provSel.options[provSel.selectedIndex].text; hidProv.value = provSel.value; }

const grid = $('#grid'), q=$('#q'), fcat=$('#f-cat'), fasoc=$('#f-asoc'), fmin=$('#f-min');
function renderCatalog(){
  const term=(q.value||'').toLowerCase().trim(), cat=fcat.value, onlyAsoc=fasoc.checked, onlyMin=fmin.checked;
  grid.innerHTML=''; let lista=CATALOGO;
  if(PROV_ID && MAPA_PROV[PROV_ID]){ const ids=MAPA_PROV[PROV_ID]; lista=lista.filter(p=>ids.includes(p.id)); }
  lista.filter(p=>(!term||p.nombre.toLowerCase().includes(term)))
       .filter(p=>(!cat||p.categoria===cat))
       .filter(p=>(!onlyAsoc||p.asoc===1))
       .filter(p=>(!onlyMin||p.stock<=p.min))
       .forEach(p=>{
        const n=document.createElement('div'); n.className='product';
        n.innerHTML=`
          <h4>${p.nombre} <span style="font-size:12px;color:#6b7280">${p.presentacion||''}</span></h4>
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            <span class="badge"><i class="fa-solid fa-tag"></i> ${p.categoria}</span>
            <span class="badge green"><i class="fa-solid fa-box"></i> Stock: ${p.stock}</span>
            <span class="badge orange"><i class="fa-solid fa-gauge-high"></i> Min: ${p.min}</span>
          </div>
          <div style="font-size:13px;color:#374151">Precio: $${fmt(p.precio)} ${p.lote?`| Lote: ${p.lote}`:''} ${p.vto?`| Vto: ${p.vto}`:''}</div>
          <div style="display:flex;gap:8px;align-items:center;margin-top:auto">
            <input id="qty-${p.id}" class="input" type="number" min="1" value="1" style="width:80px">
            <input id="cost-${p.id}" class="input" type="number" step="0.01" min="0" placeholder="Costo" style="width:110px">
            <button class="btn primary" onclick="addToCart(${p.id})"><i class="fa-solid fa-plus"></i> Añadir</button>
          </div>`;
        grid.appendChild(n);
       });
  if(!grid.children.length){ grid.innerHTML='<div style="text-align:center;color:#6b7280;padding:20px">No hay productos disponibles.</div>'; }
}
[q,fcat,fasoc,fmin].forEach(e=>e.addEventListener('input',renderCatalog)); renderCatalog();

let CART={};
const cartBody=$('#cart-body'), emptyRow=$('#empty'), hidLines=$('#hid-lines'), btnSave=$('#btn-save');
function addToCart(id){
  const p=CATALOGO.find(x=>x.id===id); if(!p)return;
  let q=parseInt(document.querySelector(`#qty-${id}`)?.value||'1',10); q=Math.max(1,q);
  let c=parseFloat(document.querySelector(`#cost-${id}`)?.value||'0'); c=Math.max(0,c);
  if(!CART[id]){ CART[id]={id:p.id,nombre:p.nombre,presentacion:p.presentacion,categoria:p.categoria,precio:p.precio,cant:q,costo:c>0?c:p.precio,lote:p.lote||'',vto:p.vto||''}; }
  else{ CART[id].cant+=q; if(c>0)CART[id].costo=c; }
  renderCart();
}
function removeFromCart(id){ delete CART[id]; renderCart(); }
function setField(id,field,value){
  const r=CART[id]; if(!r)return;
  if(field==='cant'){r.cant=Math.max(1,parseInt(value||'1',10));}
  else if(field==='costo'){r.costo=Math.max(0,parseFloat(value||'0'));}
  else if(field==='lote'){r.lote=value;}
  else if(field==='vto'){r.vto=value;}
  renderTotals(false);
}
function renderCart(){
  emptyRow.style.display=Object.keys(CART).length?'none':'';
  cartBody.querySelectorAll('tr[data-id]').forEach(tr=>tr.remove());
  Object.values(CART).forEach(p=>{
    const tr=document.createElement('tr'); tr.dataset.id=p.id;
    const sub=p.cant*(p.costo||0);
    tr.innerHTML=`
      <td>${p.nombre}</td><td>${p.presentacion||''}</td><td>${p.categoria||''}</td>
      <td>$${fmt(p.precio||0)}</td>
      <td><input class="input" style="width:70px" type="number" min="1" value="${p.cant}" oninput="setField(${p.id},'cant',this.value)"></td>
      <td><input class="input" style="width:90px" type="number" step="0.01" value="${p.costo||''}" oninput="setField(${p.id},'costo',this.value)"></td>
      <td><input class="input" style="width:90px" value="${p.lote||''}" oninput="setField(${p.id},'lote',this.value)"></td>
      <td><input class="input" style="width:110px" type="date" value="${p.vto||''}" oninput="setField(${p.id},'vto',this.value)"></td>
      <td>$${fmt(sub)}</td>
      <td><button class="btn" style="background:#f59e0b;color:#fff" onclick="removeFromCart(${p.id})"><i class="fa-solid fa-xmark"></i></button></td>`;
    cartBody.appendChild(tr);
  });
  renderTotals(true);
}
function renderTotals(updateHidden){
  let total=0; Object.values(CART).forEach(p=> total+=p.cant*(p.costo||0));
  document.getElementById('total').textContent=`$${fmt(total)}`;
  btnSave.disabled=!provSel.value||Object.keys(CART).length===0||total<=0;
  if(updateHidden){
    const obs=document.getElementById('obs').value;
    document.getElementById('hid-obs').value=obs;
    hidProv.value=provSel.value;
    hidLines.innerHTML='';
    Object.values(CART).forEach(p=>{
      hidLines.insertAdjacentHTML('beforeend',`
        <input type="hidden" name="items[${p.id}][id]" value="${p.id}">
        <input type="hidden" name="items[${p.id}][cant]" value="${p.cant}">
        <input type="hidden" name="items[${p.id}][costo]" value="${p.costo}">
        <input type="hidden" name="items[${p.id}][lote]" value="${p.lote||''}">
        <input type="hidden" name="items[${p.id}][vto]" value="${p.vto||''}">
      `);
    });
  }
}
document.getElementById('f').addEventListener('submit',()=>{
  document.getElementById('hid-obs').value=document.getElementById('obs').value;
});
</script>
</body>
</html>

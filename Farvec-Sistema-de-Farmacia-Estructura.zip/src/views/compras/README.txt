📁 Carpeta: src/views/compras
Colocá aquí los archivos correspondientes a esta sección del sistema Farvec.
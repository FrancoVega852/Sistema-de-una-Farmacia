Esta carpeta pertenece a src/views del proyecto Farvec - Sistema de Farmacia.
Agrega aquí los archivos correspondientes.
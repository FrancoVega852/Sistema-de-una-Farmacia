<?php
session_start();
require_once 'Conexion.php';
require_once 'Venta.php';
require_once 'ControladorVentas.php';

if (!isset($_SESSION['usuario_id'])) {
  header("Location: login.php");
  exit();
}

$conn = new Conexion();
$ctl  = new ControladorVentas($conn->conexion);

// Datos
$clientesRes  = $ctl->clientes();
$productosRes = $ctl->productos();

// Convertimos resultados a arrays para JS
$clientes = [];
while ($c = $clientesRes->fetch_assoc()) { $clientes[] = $c; }

$productos = [];
while ($p = $productosRes->fetch_assoc()) {
  $productos[] = [
    'id' => (int)$p['id'],
    'nombre' => $p['nombre'],
    'precio' => (float)$p['precio'],
    'stock'  => (int)$p['stock_actual'],
    'categoria' => $p['categoria'] ?? 'General',
    'requiere_receta' => (int)($p['requiere_receta'] ?? 0),
  ];
}
?>
<!DOCTYPE html>
<html lang="es" data-theme="light">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Nueva Venta - Farvec</title>

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
  --verde:#16a34a; --verde-oscuro:#15803d; --acento:#e85c4a;
  --azul:#2563eb; --bg:#f0fdf4; --white:#fff; --text:#1f2937; --muted:#6b7280; --borde:#e5e7eb;
  --card:#ffffff; --card-sub:#f9fafb; --chip:#ffffff;
  --shadow: 0 8px 24px rgba(0,0,0,.08);
}
html, body{height:100%;min-height:100vh;}
body{
  margin:0;
  font-family:Segoe UI,system-ui,-apple-system,sans-serif;
  color:var(--text);
  position: relative; overflow-x: hidden;
}

/* ===== FONDO A PANTALLA COMPLETA + PASTILLAS ===== */
.bg-verde{
  position: fixed; inset: 0; z-index: 0; pointer-events: none;
  background: linear-gradient(180deg, #c9ffd8 0%, #a6f5b4 40%, #92ed9f 100%);
  background-attachment: fixed;
}
.bg-pastillas{
  position: fixed; inset: 0; z-index: 1; pointer-events: none;
  background-image: url("data:image/svg+xml,%3Csvg width='140' height='140' viewBox='0 0 140 140' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2300683730'%3E%3Cellipse cx='30' cy='30' rx='12' ry='5' transform='rotate(30 30 30)'/%3E%3Cellipse cx='90' cy='25' rx='10' ry='4' transform='rotate(-25 90 25)'/%3E%3Cellipse cx='60' cy='90' rx='8' ry='3.5' transform='rotate(40 60 90)'/%3E%3Crect x='70' y='60' width='16' height='6' rx='3' transform='rotate(45 70 60)'/%3E%3Ccircle cx='40' cy='110' r='5'/%3E%3Ccircle cx='115' cy='100' r='4'/%3E%3C/g%3E%3C/svg%3E");
  background-size: 160px 160px;
  opacity: .75;
  animation: pillsMove 40s linear infinite alternate;
}
@keyframes pillsMove{ 0%{background-position:0 0} 100%{background-position:200px 200px} }

/* ===== TOPBAR ===== */
.topbar{
  position: sticky; top:0; z-index: 10;
  background: linear-gradient(90deg,var(--verde-oscuro),var(--verde));
  color:#fff; box-shadow:0 4px 15px rgba(0,0,0,.15);
}
.topbar .btn-back{
  background:#fff; color:var(--verde-oscuro); border:0;
  font-weight:600; border-radius:10px; padding:.6rem .9rem; transition:.2s;
}
.topbar .btn-back:hover{ transform:translateY(-2px) scale(1.02); box-shadow:0 6px 16px rgba(0,0,0,.2) }
.h1{display:flex;align-items:center;gap:.6rem;font-size:1.25rem;font-weight:800}

/* ===== WRAPPER ===== */
.wrap{ position:relative; z-index: 2; }

/* ===== PANELS (usas Bootstrap Cards + mejoras) ===== */
.panel{ background:var(--card); border:1px solid var(--borde); border-radius:16px; box-shadow: var(--shadow); overflow:hidden; animation:slideUp .6s ease }
.panel-header{ background:var(--card-sub); border-bottom:1px solid var(--borde) }
.panel-title{ display:flex; align-items:center; gap:.5rem }
.panel-title h2{ margin:0; font-size:1.125rem; color:var(--verde-oscuro) }
.panel-body{ padding:1rem }

/* ===== FILTROS ===== */
.filters{display:flex;flex-wrap:wrap;gap:.5rem  .75rem;margin-bottom:.75rem}
.input, select{
  padding:.6rem .75rem; border:1px solid var(--borde); border-radius:10px; outline:none; min-width:200px; transition:.3s; background:#fff;
}
.input:focus, select:focus{border-color:var(--verde); box-shadow:0 0 0 3px rgba(22,163,74,.15)}
.chip{
  display:inline-flex; align-items:center; gap:.4rem; padding:.45rem .7rem; border-radius:999px;
  border:1px solid var(--borde); background:var(--chip); cursor:pointer; transition:.25s;
}
.chip:hover{ background:#f0fdf4 }

/* ===== GRID PRODUCTOS ===== */
.grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:.85rem }
.card-prod{
  border:1px solid var(--borde); border-radius:14px; padding:.9rem; display:flex; flex-direction:column; gap:.5rem;
  background:#fff; min-height:160px; position:relative; transition:.25s;
}
.card-prod:hover{ transform:translateY(-4px); box-shadow:0 12px 28px rgba(0,0,0,.12) }
.card-prod h4{ margin:0; font-size:1rem; font-weight:700 }
.price{ font-weight:800; color:var(--azul); font-size:.98rem }
.meta{ font-size:.8rem; color:var(--muted); display:flex; gap:.35rem; flex-wrap:wrap }
.badge-lite{
  display:inline-flex; align-items:center; gap:.35rem; padding:.25rem .55rem; border-radius:999px;
  border:1px solid var(--borde); font-size:.75rem;
}
.badge-lite.green{ background:#ecfdf5; color:#065f46; border-color:#a7f3d0 }
.badge-lite.red{ background:#fee2e2; color:#991b1b; border-color:#fecaca }
.controls{ display:flex; gap:.5rem; margin-top:auto }
.qty{ width:74px }
.btn-add{
  flex:1; background:var(--verde); color:#fff; border:none; border-radius:10px; padding:.55rem .7rem; cursor:pointer; transition:.25s; font-weight:700;
}
.btn-add:hover{ transform: translateY(-1px) }
.btn-add:disabled{ background:#9ca3af; cursor:not-allowed }

/* ===== CARRITO ===== */
.small{ font-size:.86rem; color:var(--muted) }
.select{ min-width:220px }
.table-cart th{ background:#dcfce7; color:#065f46; font-weight:700 }
.table-cart td, .table-cart th{ vertical-align: middle }
.qty-row{ display:flex; align-items:center; gap:.35rem }

/* ===== RESUMEN ===== */
.summary{
  background:#ecfdf5; border:1px dashed #86efac; border-radius:14px; padding:.9rem; margin-top:.75rem; animation:fadeIn .6s ease
}
.summary .row-line{ display:flex; justify-content:space-between; margin:.35rem 0 }
#s-total{
  background:linear-gradient(90deg,#16a34a,#22c55e);
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; font-weight:900;
}

/* ===== FOOTER ===== */
.footer{ position:relative; z-index:2; margin-top:1rem; padding:.75rem; text-align:center; color:var(--muted); font-size:.85rem }

/* ===== ANIMACIONES ===== */
@keyframes fadeIn{ from{opacity:0} to{opacity:1} }
@keyframes slideUp{ from{opacity:0; transform:translateY(20px)} to{opacity:1; transform:none} }

/* ===== MODO OSCURO ===== */
html[data-theme="dark"]{
  --text:#e5e7eb; --muted:#cbd5e1; --borde:#2b3542;
  --card:#0f172a; --card-sub:#0b1222; --chip:#0f172a;
  --shadow: 0 8px 24px rgba(0,0,0,.35);
}
html[data-theme="dark"] body{ color:var(--text) }
/* Fondo en dark */
html[data-theme="dark"] .bg-verde{
  background: linear-gradient(180deg, #083d2a 0%, #0b5b3e 40%, #0c6b49 100%);
}
html[data-theme="dark"] .bg-pastillas{ opacity:.33 }
/* Cards / inputs / tablas */
html[data-theme="dark"] .panel,
html[data-theme="dark"] .card-prod,
html[data-theme="dark"] .input,
html[data-theme="dark"] select,
html[data-theme="dark"] .table-cart,
html[data-theme="dark"] .chip { background: var(--card); color: var(--text); }
html[data-theme="dark"] .panel-header{ background: var(--card-sub) }
html[data-theme="dark"] .table-cart th{ background:#064e3b; color:#dcfce7 }
html[data-theme="dark"] .badge-lite{ border-color:#334155 }
/* Botones Bootstrap variantes en dark (bordes) */
html[data-theme="dark"] .btn{ border-color:#334155 }
/* ✅ Negritas y títulos en blanco para legibilidad */
html[data-theme="dark"] strong,
html[data-theme="dark"] b,
html[data-theme="dark"] .fw-bold,
html[data-theme="dark"] h1,
html[data-theme="dark"] h2,
html[data-theme="dark"] h3,
html[data-theme="dark"] h4,
html[data-theme="dark"] h5,
html[data-theme="dark"] h6 { color: #ffffff !important; }
</style>
</head>
<body>

<!-- FONDO -->
<div class="bg-verde" aria-hidden="true"></div>
<div class="bg-pastillas" aria-hidden="true"></div>

<!-- TOP -->
<nav class="topbar navbar navbar-expand px-3 py-2">
  <div class="d-flex align-items-center gap-2 w-100">
    <a href="ventas_listar.php" class="btn-back d-inline-flex align-items-center">
      <i class="fa-solid fa-arrow-left me-1"></i> Volver
    </a>
    <div class="h1 ms-2 me-auto">
      <i class="fa-solid fa-cash-register"></i> Nueva Venta
    </div>
    <!-- Toggle modo oscuro -->
    <button id="themeToggle" class="btn btn-sm btn-light fw-bold">
      <i class="fa-solid fa-moon me-1"></i><span id="themeTxt">Modo oscuro</span>
    </button>
  </div>
</nav>

<div class="wrap container-xxl py-3">

  <div class="row g-3">
    <!-- CATÁLOGO -->
    <div class="col-12 col-lg-7">
      <section class="panel card h-100">
        <div class="panel-header card-header d-flex align-items-center justify-content-between">
          <div class="panel-title">
            <i class="fa-solid fa-capsules" style="color:var(--verde-oscuro)"></i>
            <h2>Catálogo</h2>
          </div>
          <div class="small">Productos disponibles: <strong><?= count($productos) ?></strong></div>
        </div>
        <div class="panel-body card-body">
          <div class="filters">
            <input id="q" class="input form-control" type="search" placeholder="Buscar por nombre…">
            <select id="f-cat" class="form-select" style="min-width:220px">
              <option value="">Todas las categorías</option>
              <?php
                $cats = array_values(array_unique(array_map(fn($r)=>$r['categoria'],$productos)));
                sort($cats);
                foreach($cats as $cat) echo '<option>'.htmlspecialchars($cat).'</option>';
              ?>
            </select>
            <label class="chip">
              <input id="f-stock" type="checkbox" class="form-check-input me-1"> Solo con stock
            </label>
            <label class="chip">
              <input id="f-receta" type="checkbox" class="form-check-input me-1"> Requiere receta
            </label>
          </div>
          <div id="grid" class="grid"></div>
        </div>
      </section>
    </div>

    <!-- CARRITO -->
    <div class="col-12 col-lg-5">
      <section class="panel card h-100">
        <div class="panel-header card-header d-flex align-items-center">
          <div class="panel-title">
            <i class="fa-solid fa-basket-shopping" style="color:var(--verde-oscuro)"></i>
            <h2>Carrito</h2>
          </div>
          <div class="small ms-auto">Todos los importes incluyen IVA</div>
        </div>
        <div class="panel-body card-body">
          <div class="d-flex flex-wrap gap-2 mb-2">
            <select id="cliente" class="form-select select">
              <option value="">Consumidor Final</option>
              <?php foreach($clientes as $c): ?>
                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['nombre'].' '.$c['apellido']) ?></option>
              <?php endforeach; ?>
            </select>
            <select id="pago" class="form-select select">
              <option value="Efectivo">Efectivo</option>
              <option value="Tarjeta">Tarjeta</option>
              <option value="Cuenta Corriente">Cuenta Corriente</option>
            </select>
            <input id="nota" class="input form-control flex-grow-1" placeholder="Nota en ticket (opcional)">
          </div>

          <div class="border rounded-3 overflow-auto" style="max-height:420px; border-color:var(--borde)!important">
            <table class="table table-cart mb-0" id="cart">
              <thead>
                <tr>
                  <th>Producto</th><th>Precio</th><th style="width:170px">Cantidad</th><th>Stock</th><th>Subtotal</th><th>Acción</th>
                </tr>
              </thead>
              <tbody id="cart-body">
                <tr id="empty-row">
                  <td colspan="6" class="small text-center py-3">Agrega productos desde el catálogo ➜</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div class="summary mt-3">
            <div class="row-line"><span>Subtotal</span><strong id="s-subtotal">$0,00</strong></div>
            <div class="row-line"><span>IVA (21%)</span><strong id="s-iva">$0,00</strong></div>
            <div class="row-line align-items-center gap-2">
              <span>Descuento</span>
              <div class="d-flex align-items-center gap-2">
                <input id="descuento" type="number" value="0" min="0" max="100" class="input form-control" style="width:90px"> %
              </div>
            </div>
            <div class="row-line pt-2" style="border-top:1px dashed #86efac">
              <span>Total</span><strong id="s-total" style="font-size:20px">$0,00</strong>
            </div>
          </div>

          <div class="d-flex align-items-center gap-2 mt-3">
            <button class="btn btn-warning text-white fw-bold" type="button" onclick="limpiarCarrito()">
              <i class="fa-solid fa-rotate-left"></i> Vaciar
            </button>
            <button class="btn btn-outline-secondary fw-bold" type="button" onclick="window.print()">
              <i class="fa-solid fa-print"></i> Imprimir
            </button>

            <form id="venta-form" method="POST" action="ventas_guardar.php" class="ms-auto d-flex gap-2">
              <input type="hidden" name="cliente_id" id="cliente_id">
              <div id="hidden-lines"></div>
              <button id="btn-registrar" class="btn btn-success fw-bold" disabled>
                <i class="fa-solid fa-floppy-disk"></i> Registrar Venta
              </button>
            </form>
          </div>

        </div>
      </section>
    </div>
  </div>
</div>

<div class="footer">Farvec POS • <?= date('Y') ?></div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
/* ======= Toggle Modo Oscuro persistente ======= */
(function(){
  const root = document.documentElement;
  const btn  = document.getElementById('themeToggle');
  const txt  = document.getElementById('themeTxt');
  const saved = localStorage.getItem('theme') || 'light';
  root.setAttribute('data-theme', saved);
  txt.textContent = saved==='dark' ? 'Modo claro' : 'Modo oscuro';
  btn.innerHTML = saved==='dark'
    ? '<i class="fa-solid fa-sun me-1"></i><span id="themeTxt">Modo claro</span>'
    : '<i class="fa-solid fa-moon me-1"></i><span id="themeTxt">Modo oscuro</span>';

  btn.addEventListener('click', ()=>{
    const cur = root.getAttribute('data-theme') === 'dark' ? 'light':'dark';
    root.setAttribute('data-theme', cur);
    localStorage.setItem('theme', cur);
    btn.innerHTML = cur==='dark'
      ? '<i class="fa-solid fa-sun me-1"></i><span id="themeTxt">Modo claro</span>'
      : '<i class="fa-solid fa-moon me-1"></i><span id="themeTxt">Modo oscuro</span>';
  });
})();

/* ======= Tu JS original sin cambios (con leves mejoras visuales Bootstrap-friendly) ======= */
const CATALOGO = <?php echo json_encode($productos, JSON_UNESCAPED_UNICODE); ?>;
const fmt = n => n.toLocaleString('es-AR',{minimumFractionDigits:2, maximumFractionDigits:2});
const $  = sel => document.querySelector(sel);

const grid = $('#grid'), q=$('#q'), fcat=$('#f-cat'), fstock=$('#f-stock'), freceta=$('#f-receta');
const cartBody = $('#cart-body'), emptyRow = $('#empty-row'), hiddenLines = $('#hidden-lines'), btnRegistrar = $('#btn-registrar');
const form = $('#venta-form'), clienteSel = $('#cliente'), clienteId = $('#cliente_id'), descuento = $('#descuento');
let CART = {};

function renderCatalog(){
  const term=(q.value||'').toLowerCase().trim(), cat=fcat.value;
  const onlyStock=fstock.checked, onlyReceta=freceta.checked;
  grid.innerHTML='';
  CATALOGO
    .filter(p=>(!term||p.nombre.toLowerCase().includes(term)))
    .filter(p=>(!cat||p.categoria===cat))
    .filter(p=>(!onlyStock||p.stock>0))
    .filter(p=>(!onlyReceta||p.requiere_receta===1))
    .forEach(p=>{
      const disabled=p.stock<=0, receta=p.requiere_receta===1?`<span class="badge-lite red"><i class="fa-solid fa-prescription"></i> Receta</span>`:'';
      const node=document.createElement('div');
      node.className='card-prod';
      node.innerHTML=`
        <h4 class="fw-bold">${p.nombre}</h4>
        <div class="meta">
          <span class="badge-lite"><i class="fa-solid fa-tag"></i> ${p.categoria}</span>
          <span class="badge-lite green"><i class="fa-solid fa-box"></i> Stock: ${p.stock}</span>
          ${receta}
        </div>
        <div class="price">$${fmt(p.precio)}</div>
        <div class="controls">
          <input type="number" min="1" value="1" class="input form-control qty" id="qty-${p.id}">
          <button class="btn-add" ${disabled?'disabled':''} onclick="addToCart(${p.id})">
            <i class="fa-solid fa-plus"></i> Añadir
          </button>
        </div>`;
      grid.appendChild(node);
    });
  if(!grid.children.length){
    grid.innerHTML='<div class="card-prod text-center text-muted" style="grid-column:1/-1">No hay productos que coincidan.</div>';
  }
}
[q,fcat,fstock,freceta].forEach(el=>el.addEventListener('input',renderCatalog));renderCatalog();

function addToCart(id){
  const p=CATALOGO.find(x=>x.id===id);if(!p)return;
  let qtyEl=document.querySelector(`#qty-${id}`);let qty=Math.max(1,parseInt(qtyEl?.value||'1',10));
  if(qty>p.stock)qty=p.stock;
  if(CART[id])CART[id].qty=Math.min(p.stock,CART[id].qty+qty);else CART[id]={...p,qty};
  renderCart();qtyEl.value=1;
}
function removeFromCart(id){delete CART[id];renderCart();}
function setQty(id,q){const p=CART[id];if(!p)return;q=Math.max(1,Math.min(p.stock,parseInt(q||'1',10)));p.qty=q;renderCart(false);}
function renderCart(updateHidden=true){
  emptyRow.style.display=Object.keys(CART).length?'none':'';cartBody.querySelectorAll('tr[data-id]').forEach(tr=>tr.remove());
  let subtotal=0;
  Object.values(CART).forEach(p=>{
    const sub=p.qty*p.precio;subtotal+=sub;
    const tr=document.createElement('tr');tr.dataset.id=p.id;
    tr.innerHTML=`<td class="fw-semibold">${p.nombre}</td>
      <td>$${fmt(p.precio)}</td>
      <td>
        <div class="qty-row">
          <button class="btn btn-outline-secondary btn-sm" type="button" onclick="setQty(${p.id},${p.qty-1})">-</button>
          <input class="input form-control form-control-sm text-center" style="width:70px" value="${p.qty}" oninput="setQty(${p.id},this.value)">
          <button class="btn btn-outline-secondary btn-sm" type="button" onclick="setQty(${p.id},${p.qty+1})">+</button>
        </div>
      </td>
      <td>${p.stock}</td>
      <td>$${fmt(sub)}</td>
      <td><button class="btn btn-danger btn-sm" type="button" onclick="removeFromCart(${p.id})"><i class="fa-solid fa-trash"></i></button></td>`;
    cartBody.appendChild(tr);
  });
  const iva=subtotal*0.21, desc=Math.min(100,Math.max(0,parseFloat(descuento.value||'0'))), total=subtotal*(1-desc/100);
  document.getElementById('s-subtotal').textContent=`$${fmt(subtotal)}`;
  document.getElementById('s-iva').textContent=`$${fmt(iva)}`;
  document.getElementById('s-total').textContent=`$${fmt(total)}`;
  if(updateHidden){
    hiddenLines.innerHTML='';
    Object.values(CART).forEach(p=>{
      hiddenLines.innerHTML+=`<input type="hidden" name="productos[${p.id}][id]" value="${p.id}">
                               <input type="hidden" name="productos[${p.id}][cantidad]" value="${p.qty}">`;
    });
  }
  btnRegistrar.disabled=Object.keys(CART).length===0;
}
function limpiarCarrito(){CART={};renderCart();}
form.addEventListener('submit',()=>{clienteId.value=clienteSel.value;});
descuento.addEventListener('input',()=>renderCart(false));
</script>
</body>
</html>

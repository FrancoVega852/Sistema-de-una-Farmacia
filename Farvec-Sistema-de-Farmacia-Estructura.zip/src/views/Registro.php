<?php
session_start();
include 'Conexion.php';
include 'Usuario.php';

class RegistroController {
    private $usuario;
    public $mensaje = "";

    public function __construct($conexion) {
        $this->usuario = new Usuario($conexion);
    }

    public function procesarFormulario() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre     = trim($_POST['nombre']);
            $apellido   = trim($_POST['apellido']);
            $dni        = trim($_POST['dni']);
            $domicilio  = trim($_POST['domicilio']);
            $correo     = trim($_POST['correo']);
            $telefono   = trim($_POST['telefono']);
            $contrasena = $_POST['contrasena'];
            $rol        = $_POST['rol'];

            if ($this->usuario->registrar($nombre, $apellido, $correo, $dni, $domicilio, $telefono, $contrasena, $rol)) {
                header("Location: login.php?registro=exitoso");
                exit();
            } else {
                $this->mensaje = "⚠️ Error al registrar usuario. Intente nuevamente.";
            }
        }
    }
}

$conn = new Conexion();
$controller = new RegistroController($conn->conexion);
$controller->procesarFormulario();
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>Registro - Sistema de Farmacia</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" />
  <style>
    :root {
      --verde: #008f4c;
      --verde-oscuro: #006837;
      --blanco: #ffffff;
      --acento: #e85c4a;
      --texto: #222222;
    }

    body {
      margin: 0;
      font-family: 'Inter', sans-serif;
      background-color: var(--verde);
      /* 💊 Fondo con pastillas y cruces */
      background-image: url("data:image/svg+xml,%3Csvg width='120' height='120' viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%23ffffff22'%3E%3Cellipse cx='20' cy='20' rx='10' ry='4' transform='rotate(40 20 20)'/%3E%3Cellipse cx='90' cy='25' rx='9' ry='3.5' transform='rotate(-35 90 25)'/%3E%3Cellipse cx='50' cy='80' rx='8' ry='4' transform='rotate(30 50 80)'/%3E%3Crect x='70' y='60' width='12' height='5' rx='2.5' transform='rotate(45 70 60)'/%3E%3Ccircle cx='30' cy='95' r='4'/%3E%3Ccircle cx='100' cy='90' r='3.5'/%3E%3Cpath d='M10 70l8 8m0-8l-8 8' stroke='%23ffffff33' stroke-width='2' stroke-linecap='round'/%3E%3Cpath d='M60 10l6 6m0-6l-6 6' stroke='%23ffffff33' stroke-width='2' stroke-linecap='round'/%3E%3C/g%3E%3C/svg%3E");
      background-repeat: repeat;
      background-size: 160px 160px;
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      animation: fadeIn 1.2s ease;
      padding: 1rem;
    }

    .form-box {
      background: rgba(255, 255, 255, 0.9);
      backdrop-filter: blur(15px);
      border-radius: 1.2rem;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.25);
      width: 100%;
      max-width: 520px;
      padding: 2rem 2.5rem;
      animation: slideUp 1s ease;
    }

    .form-box h2 {
      color: var(--verde-oscuro);
      text-align: center;
      font-weight: 700;
      margin-bottom: 1.5rem;
    }

    .icono {
      background: var(--verde-oscuro);
      color: white;
      width: 70px;
      height: 70px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 30px;
      margin: 0 auto 1rem auto;
      box-shadow: 0 6px 15px rgba(0, 0, 0, 0.3);
    }

    label {
      font-weight: 600;
      color: var(--texto);
    }

    .form-control:focus {
      border-color: var(--verde);
      box-shadow: 0 0 0 0.2rem rgba(0,143,76,0.25);
    }

    .btn-verde {
      background-color: var(--verde);
      color: white;
      font-weight: 600;
      border: none;
      transition: all 0.3s ease;
    }

    .btn-verde:hover {
      background-color: var(--verde-oscuro);
      transform: scale(1.02);
    }

    .mensaje {
      margin-top: 1rem;
      text-align: center;
      background: #ffecec;
      color: var(--acento);
      font-weight: 600;
      padding: 0.6rem;
      border-radius: 8px;
    }

    p {
      text-align: center;
      margin-top: 1rem;
      color: var(--texto);
    }

    p a {
      color: var(--verde);
      text-decoration: none;
      font-weight: 600;
    }

    p a:hover {
      text-decoration: underline;
      color: var(--verde-oscuro);
    }

    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slideUp { from { transform: translateY(40px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
  </style>
</head>
<body>
  <div class="form-box">
    <div class="icono"><i class="fas fa-user-plus"></i></div>
    <h2>Crear cuenta - Farvec</h2>

    <form method="POST" class="row g-3">
      <div class="col-md-6">
        <label for="nombre" class="form-label">Nombre</label>
        <input type="text" name="nombre" id="nombre" class="form-control" required>
      </div>

      <div class="col-md-6">
        <label for="apellido" class="form-label">Apellido</label>
        <input type="text" name="apellido" id="apellido" class="form-control" required>
      </div>

      <div class="col-md-6">
        <label for="correo" class="form-label">Correo Electrónico</label>
        <input type="email" name="correo" id="correo" class="form-control" required>
      </div>

      <div class="col-md-6">
        <label for="contrasena" class="form-label">Contraseña</label>
        <input type="password" name="contrasena" id="contrasena" class="form-control" required>
      </div>

      <div class="col-md-6">
        <label for="dni" class="form-label">DNI</label>
        <input type="text" name="dni" id="dni" class="form-control" required>
      </div>

      <div class="col-md-6">
        <label for="telefono" class="form-label">Teléfono</label>
        <input type="text" name="telefono" id="telefono" class="form-control" required>
      </div>

      <div class="col-12">
        <label for="domicilio" class="form-label">Domicilio</label>
        <input type="text" name="domicilio" id="domicilio" class="form-control" required>
      </div>

      <div class="col-12">
        <label for="rol" class="form-label">Rol</label>
        <select name="rol" id="rol" class="form-select" required>
          <option value="">Seleccione un rol</option>
          <option value="Cliente">Cliente</option>
          <option value="Empleado">Empleado</option>
          <option value="Farmaceutico">Farmacéutico</option>
          <option value="Administrador">Administrador</option>
        </select>
      </div>

      <div class="col-12">
        <button type="submit" class="btn btn-verde w-100 mt-2 py-2">Registrarse</button>
      </div>

      <?php if (!empty($controller->mensaje)): ?>
        <div class="col-12">
          <div class="mensaje"><?= htmlspecialchars($controller->mensaje) ?></div>
        </div>
      <?php endif; ?>
    </form>

    <p>¿Ya tienes una cuenta? <a href="login.php">Inicia sesión</a></p>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

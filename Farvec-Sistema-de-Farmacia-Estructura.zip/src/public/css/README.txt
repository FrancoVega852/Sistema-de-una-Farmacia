📁 Carpeta: src/public/css
Colocá aquí los archivos correspondientes a esta sección del sistema Farvec.
📁 Carpeta: src/public/img
Colocá aquí los archivos correspondientes a esta sección del sistema Farvec.
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Farvec - Sistema de Gestión Farmacéutica</title>

  <!-- Bootstrap & FontAwesome -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css"/>
  <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet"/>

  <style>
    :root {
      --verde: #008f4c;
      --verde-oscuro: #006837;
      --blanco: #ffffff;
      --acento: #e85c4a;
      --texto: #1f2937;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    /* 💚 Fondo verde degradado */
    body {
      font-family: 'Segoe UI', sans-serif;
      color: var(--texto);
      background: linear-gradient(180deg, #c9ffd8 0%, #a6f5b4 40%, #92ed9f 100%);
      background-attachment: fixed;
      position: relative;
      overflow-x: hidden;
      animation: fadeInBody 1.5s ease;
    }

    @keyframes fadeInBody { from { opacity: 0; } to { opacity: 1; } }

    /* 💊 Capa de pastillas fija */
    .fondo-pastillas {
      position: fixed;
      inset: 0;
      z-index: 0;
      pointer-events: none;
      background-image: url("data:image/svg+xml,%3Csvg width='120' height='120' viewBox='0 0 120 120' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='%2300683720'%3E%3Cellipse cx='20' cy='20' rx='10' ry='4' transform='rotate(40 20 20)'/%3E%3Cellipse cx='90' cy='25' rx='9' ry='3.5' transform='rotate(-35 90 25)'/%3E%3Cellipse cx='50' cy='80' rx='8' ry='4' transform='rotate(30 50 80)'/%3E%3Crect x='70' y='60' width='12' height='5' rx='2.5' transform='rotate(45 70 60)'/%3E%3Ccircle cx='30' cy='95' r='4'/%3E%3Ccircle cx='100' cy='90' r='3.5'/%3E%3Cpath d='M10 70l8 8m0-8l-8 8' stroke='%2300683725' stroke-width='2' stroke-linecap='round'/%3E%3Cpath d='M60 10l6 6m0-6l-6 6' stroke='%2300683725' stroke-width='2' stroke-linecap='round'/%3E%3C/g%3E%3C/svg%3E");
      background-size: 160px 160px;
      opacity: 0.7;
      animation: pillsMove 40s linear infinite alternate;
    }

    @keyframes pillsMove {
      0% { background-position: 0 0; }
      100% { background-position: 200px 200px; }
    }

    /* HEADER */
    header {
      background: var(--verde);
      padding: 1rem 2rem;
      display: flex;
      justify-content: space-between;
      align-items: center;
      box-shadow: 0 3px 10px rgba(0,0,0,0.2);
      position: sticky;
      top: 0;
      z-index: 5;
    }

    .logo {
      display: flex;
      align-items: center;
      gap: 10px;
      color: var(--blanco);
      font-size: 1.6rem;
      font-weight: 700;
    }

    .logo img { width: 45px; animation: pulse 2s infinite; }
    @keyframes pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.1)} }

    nav a {
      color: var(--blanco);
      text-decoration: none;
      margin: 0 14px;
      font-weight: 600;
      transition: .3s;
    }
    nav a:hover { color: var(--acento); }

    /* HERO */
    .hero {
      text-align: center;
      padding: 5rem 2rem;
      position: relative;
      z-index: 2;
    }

    .hero h1 {
      font-size: 2.9rem;
      color: var(--verde-oscuro);
      font-weight: 800;
      margin-bottom: 1rem;
    }

    .hero p {
      font-size: 1.2rem;
      color: #333;
      margin-bottom: 2rem;
    }

    .hero .btn {
      padding: 0.9rem 1.6rem;
      border-radius: 10px;
      font-weight: 700;
      box-shadow: 0 6px 12px rgba(0,0,0,0.15);
      transition: 0.3s;
    }

    .btn-login { background: var(--acento); color: var(--blanco); }
    .btn-registro { background: var(--verde); color: var(--blanco); }
    .btn-login:hover, .btn-registro:hover { transform: translateY(-3px) scale(1.05); }

    /* KPIs */
    .kpis {
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(200px,1fr));
      gap: 1.2rem;
      margin: 3rem auto;
      max-width: 1100px;
      position: relative;
      z-index: 2;
    }

    .kpi {
      background: var(--blanco);
      padding: 2rem;
      border-radius: 16px;
      text-align: center;
      box-shadow: 0 4px 15px rgba(0,0,0,0.08);
      transition: .3s;
    }
    .kpi:hover { transform: scale(1.05); box-shadow: 0 6px 18px rgba(0,0,0,0.12); }
    .kpi i { font-size: 2rem; color: var(--verde); margin-bottom: 12px; }
    .kpi h3 { font-size: 1.6rem; font-weight: 800; }
    .kpi small { color: #6b7280; }

    /* SECCIONES */
    .seccion {
      max-width: 1100px;
      margin: 3rem auto;
      padding: 2rem;
      background: rgba(255,255,255,0.9);
      border-radius: 16px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.1);
      position: relative;
      z-index: 2;
    }

    .seccion h2 {
      margin-bottom: 1.5rem;
      color: var(--verde-oscuro);
      text-align: center;
      font-weight: 800;
    }

    .funcionalidades {
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(200px,1fr));
      gap: 1.2rem;
    }

    .card {
      padding: 1.5rem;
      background: #f8f8f8;
      border-radius: 12px;
      text-align: center;
      font-weight: 600;
      color: var(--verde-oscuro);
      cursor: pointer;
      transition: .3s;
      box-shadow: 0 4px 10px rgba(0,0,0,0.08);
    }
    .card i { font-size: 2rem; margin-bottom: 8px; display: block; }
    .card:hover { background: var(--verde); color: var(--blanco); transform: translateY(-5px); }

    /* SLIDER */
    .slider {
      background: var(--verde-oscuro);
      color: var(--blanco);
      padding: 1rem;
      overflow: hidden;
      white-space: nowrap;
      position: relative;
      z-index: 2;
    }
    .slider span {
      display: inline-block;
      padding-right: 3rem;
      animation: scroll 18s linear infinite;
      font-weight: 500;
    }
    @keyframes scroll { from { transform: translateX(100%);} to { transform: translateX(-100%);} }

    /* FOOTER */
    footer {
      background: var(--verde);
      color: var(--blanco);
      padding: 2rem;
      margin-top: 2rem;
      display: grid;
      grid-template-columns: repeat(auto-fit,minmax(220px,1fr));
      gap: 1.5rem;
      position: relative;
      z-index: 2;
    }
    footer h3 { margin-bottom: 1rem; font-weight: 700; }
    footer a { color: var(--blanco); text-decoration: none; display: block; margin: 4px 0; transition:.3s; }
    footer a:hover { text-decoration: underline; color: var(--acento); }
    .copy { grid-column: 1/-1; text-align: center; margin-top: 1rem; font-size: .9rem; color: #f1f1f1; }
  </style>
</head>

<body>
  <!-- 💊 Fondo permanente -->
  <div class="fondo-pastillas"></div>

  <header>
    <div class="logo"><img src="Logo.png" alt="Farvec"> Farvec</div>
    <nav>
      <a href="#">Inicio</a>
      <a href="#func">Funcionalidades</a>
      <a href="#nosotros">Nosotros</a>
      <a href="#contacto">Contacto</a>
    </nav>
  </header>

  <section class="hero">
    <h1 data-aos="fade-down">La salud de tu farmacia está en la gestión</h1>
    <p data-aos="fade-up">Sistema integral para administrar ventas, stock, recetas y más.</p>
    <a href="Login.php" class="btn btn-login me-2" data-aos="zoom-in"><i class="fa-solid fa-right-to-bracket me-2"></i>Iniciar Sesión</a>
    <a href="Registro.php" class="btn btn-registro" data-aos="zoom-in"><i class="fa-solid fa-user-plus me-2"></i>Registrarse</a>
  </section>

  <section class="kpis container">
    <div class="kpi" data-aos="zoom-in"><i class="fa-solid fa-pills"></i><h3>150+</h3><small>Productos activos</small></div>
    <div class="kpi" data-aos="zoom-in"><i class="fa-solid fa-users"></i><h3>75</h3><small>Clientes frecuentes</small></div>
    <div class="kpi" data-aos="zoom-in"><i class="fa-solid fa-cash-register"></i><h3>320</h3><small>Ventas realizadas</small></div>
    <div class="kpi" data-aos="zoom-in"><i class="fa-solid fa-truck"></i><h3>15</h3><small>Proveedores registrados</small></div>
  </section>

  <section class="seccion" id="func">
    <h2 data-aos="fade-up">⚙ Funcionalidades principales</h2>
    <div class="funcionalidades">
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-cash-register"></i> Ventas</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-truck"></i> Compras</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-capsules"></i> Stock y Lotes</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-file-prescription"></i> Recetas</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-building"></i> Proveedores</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-credit-card"></i> Cuentas Corrientes</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-bell"></i> Alertas</div>
      <div class="card" data-aos="fade-up"><i class="fa-solid fa-chart-line"></i> Reportes</div>
    </div>
  </section>

  <div class="slider">
    <span>📢 Nueva funcionalidad: Alertas de vencimiento automático | 💊 Registro digital de recetas | 📊 Reportes avanzados en tiempo real</span>
  </div>

  <section class="seccion" id="nosotros">
    <h2 data-aos="fade-up">🌟 Sobre nosotros</h2>
    <p><strong>Misión:</strong> Brindar a las farmacias herramientas modernas que faciliten su gestión diaria.</p>
    <p><strong>Visión:</strong> Convertirnos en el sistema de gestión farmacéutica líder en LATAM.</p>
    <p><strong>Valores:</strong> Innovación, Transparencia, Compromiso con la salud.</p>
  </section>

  <footer id="contacto">
    <div>
      <h3>📞 Contacto</h3>
      <p>Email: soporte@farvec.com</p>
      <p>Tel: +54 11 2233 4455</p>
    </div>
    <div>
      <h3>🔗 Enlaces rápidos</h3>
      <a href="Login.php">Iniciar Sesión</a>
      <a href="Registro.php">Registrarse</a>
      <a href="stock.php">Gestión de Stock</a>
    </div>
    <div>
      <h3>🌍 Síguenos</h3>
      <a href="#"><i class="fa-brands fa-facebook"></i> Facebook</a>
      <a href="#"><i class="fa-brands fa-twitter"></i> Twitter</a>
      <a href="#"><i class="fa-brands fa-linkedin"></i> LinkedIn</a>
    </div>
    <div class="copy">&copy; <?= date("Y") ?> Farvec - Sistema de Gestión de Farmacia</div>
  </footer>

  <!-- JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
  <script>AOS.init({ duration: 1000 });</script>
</body>
</html>

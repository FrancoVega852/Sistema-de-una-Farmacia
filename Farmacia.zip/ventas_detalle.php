<a href="mp_generar_pago.php?venta_id=<?= $venta['id'] ?>" 
   class="btn btn-primary">
   <i class="fa-brands fa-cc-mastercard"></i> Pagar con Mercado Pago
</a>
